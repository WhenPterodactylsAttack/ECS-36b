#include <iostream>

int main() {
  std::cout << "Hello ECS36B from 58006\n";
}
